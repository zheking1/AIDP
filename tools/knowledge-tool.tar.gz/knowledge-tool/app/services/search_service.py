import json
import math
from typing import Optional

from sqlalchemy import select, or_
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.models import KtDocument, KtDocumentChunk
from app.schemas.search import SearchRequest, SearchItem, SearchResult
from app.embedding.mock_provider import MockEmbeddingProvider
from app.config import settings

embedding_provider = MockEmbeddingProvider(dimension=settings.EMBEDDING_DIMENSION)


async def search(db: AsyncSession, req: SearchRequest) -> SearchResult:
    """Search for knowledge chunks."""
    query_chunks = (
        select(KtDocumentChunk, KtDocument)
        .join(KtDocument, KtDocumentChunk.document_id == KtDocument.id)
        .where(
            KtDocumentChunk.deleted_at.is_(None),
            KtDocument.deleted_at.is_(None),
        )
    )

    scope_filters = [
        KtDocumentChunk.workspace_id == req.workspace_id,
    ]
    if req.project_id:
        scope_filters.append(
            or_(
                KtDocumentChunk.project_id == req.project_id,
                KtDocumentChunk.project_id.is_(None),
            )
        )
    query_chunks = query_chunks.where(or_(*scope_filters))

    if req.doc_types:
        query_chunks = query_chunks.where(KtDocument.doc_type.in_(req.doc_types))

    if req.query:
        query_chunks = query_chunks.where(
            KtDocumentChunk.content.ilike(f"%{req.query}%")
        )

    query_chunks = query_chunks.limit(req.top_k * 2)

    result = await db.execute(query_chunks)
    rows = result.all()

    items = []
    for chunk, doc in rows:
        keyword_score = _calculate_keyword_score(chunk.content, req.query)
        vector_score = _calculate_vector_score(chunk.embedding, req.query)
        final_score = keyword_score * 0.25 + vector_score * 0.60

        if final_score < req.min_score:
            continue

        citation_id = f"doc:{doc.id}:v:{doc.version}:chunk:{chunk.chunk_index}"

        items.append(SearchItem(
            chunk_id=chunk.id,
            document_id=doc.id,
            title=doc.title,
            content=chunk.content if req.include_content else "",
            score=round(final_score, 4),
            keyword_score=round(keyword_score, 4),
            vector_score=round(vector_score, 4),
            version=doc.version,
            citation_id=citation_id,
            source_uri=doc.source_uri,
            heading_path=chunk.heading_path or [],
            source_start_line=chunk.source_start_line,
            source_end_line=chunk.source_end_line,
        ))

    items.sort(key=lambda x: x.score, reverse=True)
    items = items[:req.top_k]

    return SearchResult(
        items=items,
        total=len(items),
        degraded=False,
    )


def _calculate_keyword_score(content: str, query: str) -> float:
    if not query:
        return 0.5
    content_lower = content.lower()
    query_lower = query.lower()
    if query_lower in content_lower:
        count = content_lower.count(query_lower)
        return min(0.5 + count * 0.1, 1.0)
    query_words = query_lower.split()
    matches = sum(1 for word in query_words if word in content_lower)
    if query_words:
        return matches / len(query_words) * 0.5
    return 0.0


def _calculate_vector_score(embedding_json: str, query: str) -> float:
    if not embedding_json:
        return 0.5
    try:
        values = json.loads(embedding_json)
        if not values:
            return 0.5
        query_emb = embedding_provider.embed(query)
        similarity = _cosine_similarity(values, query_emb.values)
        return max(0.0, min(1.0, (similarity + 1) / 2))
    except Exception:
        return 0.5


def _cosine_similarity(a: list[float], b: list[float]) -> float:
    if len(a) != len(b):
        return 0.0
    dot_product = sum(x * y for x, y in zip(a, b))
    norm_a = math.sqrt(sum(x * x for x in a))
    norm_b = math.sqrt(sum(x * x for x in b))
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return dot_product / (norm_a * norm_b)
